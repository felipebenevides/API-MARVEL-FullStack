﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVAPI.Application.ViewModels
{
    public class Item2ViewModel
    {
        public string resourceURI { get; set; }
        public string name { get; set; }
        public string type { get; set; }
    }
}
