﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVAPI.Application.ViewModels
{
    public class ComicSummaryViewModel
    {
        public string resourceURI { get; set; }
        public string name { get; set; }
    }
}
