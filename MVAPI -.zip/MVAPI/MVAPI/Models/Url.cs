﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVAPI.Models
{
    public class Url
    {
        public string type { get; set; }
        public string url { get; set; }
    }
}
