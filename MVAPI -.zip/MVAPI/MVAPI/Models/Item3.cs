﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVAPI.Models
{
    public class Item3
    {
        public string resourceURI { get; set; }
        public string name { get; set; }
    }
}
