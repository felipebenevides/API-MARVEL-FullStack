﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVAPI.Models
{
    public class ComicSummary
    {
        public string resourceURI { get; set; }
        public string name { get; set; }
    }
}
